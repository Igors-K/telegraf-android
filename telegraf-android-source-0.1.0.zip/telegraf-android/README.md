# TELEGRAF Android app — source prototype 0.1.0

Native Android / Jetpack Compose starter for WOORDEX Messenger Bridge 0.2.0.

## Included
- WOORDEX account login against `/auth/login` (password is sent over HTTPS and not saved locally).
- App-specific Bearer token storage and logout.
- Conversation list and thread view using the Bridge routes.
- Text message sending.
- Light / dark / system theme selection, persisted locally.
- 12-second refresh while a thread is open.

## Important status
This is a source prototype, not a tested release APK. The Android SDK and Gradle build toolchain were not available in the build environment, so no APK has been compiled or device-tested. The Better Messages REST response shapes and send payload must be verified against the live WOORDEX installation before calling the app production-ready. Some response field names can vary by plugin version; parsing is intentionally tolerant but needs a real-account test.

## Build
Open this folder in Android Studio (current stable), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). Requires Android SDK Platform 35 and JDK 17 or newer.

Package: `com.woordex.telegraf`
Minimum Android: 8.0 (API 26)

## API base
`https://woordex.com/wp-json/woordex-bridge/v1`

The app uses the existing WordPress/BuddyPress/Better Messages data. It does not create a separate messaging database.

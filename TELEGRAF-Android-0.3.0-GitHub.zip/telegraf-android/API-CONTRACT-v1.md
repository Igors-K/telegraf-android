# TELEGRAF ↔ WOORDEX Bridge API Contract v1 (proposed)

The Android client is designed against a stable contract. Bridge internals may use Better Messages, WordPress/BuddyPress, or dedicated services; Android should not depend on those internals.

Base URL: `https://woordex.com/wp-json/woordex-bridge/v1`
Authentication: `X-Woordex-Token: <access_token>` on all authenticated requests. JSON UTF-8. HTTPS only.

## Standard response
Successful resources return JSON with resource data (`data` or the resource-specific key). Errors return `{ "code": "...", "message": "..." }` with an appropriate HTTP status.

## Identity / contacts
- `POST /auth/login` `{username,password}` → `{access_token,user:{id,display_name,avatar_url}}`
- `POST /auth/logout`
- `GET /me`
- `GET /users?query=&page=` → users with id, display_name, username, avatar_url, presence
- `GET /users/{user_id}`

## Chats and messages
- `GET /threads?page=` → threads: id, type (`direct|group`), title, avatar_url, unread_count, last_message, updated_at, participants
- `POST /threads` `{type,title,participant_ids,avatar_url?}` → thread
- `GET /threads/{thread_id}/messages?before=&limit=` → messages
- `POST /threads/{thread_id}/messages` `{text?,attachment_ids?,reply_to_id?}` → message
- `POST /threads/{thread_id}/read` `{message_id}`
- `POST /messages/{message_id}/reaction` `{reaction}`
- `PATCH /messages/{message_id}` `{text}`
- `DELETE /messages/{message_id}`
- `POST /threads/{thread_id}/members` `{user_ids}`
- `DELETE /threads/{thread_id}/members/{user_id}`
- `PATCH /threads/{thread_id}` `{title?,avatar_url?,description?,permissions?}`

## Channels
- `GET /channels?query=&page=` → channel id, title, description, avatar_url, subscriber_count, is_subscribed
- `POST /channels` `{title,description,avatar_url?,visibility}` → channel
- `GET /channels/{channel_id}/posts?before=&limit=`
- `POST /channels/{channel_id}/posts` `{text?,attachment_ids?,youtube_url?}`
- `POST /channels/{channel_id}/subscribe`
- `DELETE /channels/{channel_id}/subscribe`
- `POST /channels/{channel_id}/comments` `{post_id,text}`
- `POST /channels/{channel_id}/admin` `{user_id,role}`

## Media
- `POST /media` multipart upload → `{id,url,mime_type,size,thumbnail_url?}`
- `GET /media/{media_id}` metadata / access URL
- Media URL responses must be authorized or time-limited. Client supports image/video/audio/document presentation.
- YouTube URLs are returned as content metadata; client embeds only supported URLs using the platform's WebView/player handling.

## Calls / live broadcasts (feature capability endpoints)
These routes are placeholders for the server adapter/provider; they are not implemented by the current Bridge prototype:
- `POST /calls` `{type:voice|video|group_video,thread_id,participant_ids}`
- `POST /calls/{call_id}/join` `{}`
- `POST /calls/{call_id}/leave` `{}`
- `POST /broadcasts` `{channel_id,title,provider}`
- `POST /broadcasts/{broadcast_id}/join` `{}`
- `POST /broadcasts/{broadcast_id}/end` `{}`

The Bridge should return provider connection credentials/metadata for a compatible calling or streaming SDK. Android UI can be implemented against the capability and session models, but calls/live streams require a real provider integration and cannot be considered working from UI alone.

## Compatibility policy
- Keep this contract stable within major version v1.
- Bridge maps to Better Messages APIs when available; missing capabilities can be implemented in Bridge or delegated to a separate service.
- Never return WordPress internal PHP objects or Better Messages-specific field names directly to Android.
- API implementation status must be advertised by `GET /status` as capabilities (`groups`, `channels`, `media`, `calls`, `broadcasts`).

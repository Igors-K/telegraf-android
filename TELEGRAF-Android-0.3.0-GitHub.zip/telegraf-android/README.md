# TELEGRAF Android — 0.3.0

Native Android / Jetpack Compose client for WOORDEX Messenger Bridge.

## Included in this project
- WOORDEX account login and app-token persistence; logout.
- Chat list and message thread view with text sending.
- 12-second polling for open thread.
- Chat / Contacts / Groups / Channels / Calls navigation.
- Group and channel creation UI (local placeholder until Bridge endpoints are implemented).
- Call, video call, and broadcast entry points prepared in the client UI.
- Light, dark, and system themes.
- API contract document describing the intended Bridge client surface.
- GitHub Actions workflow to build a debug APK and publish it as an Actions artifact.

## Honest integration status
This is a buildable Android client codebase and feature UI foundation, **not a production Telegram-equivalent server implementation**. Direct chat login, thread list, thread read, and text sending call the current Bridge routes. Group/channel creation, contacts discovery, media upload, calls, livestreams, reactions, channel posts, and notifications need their Bridge/server endpoints and actual integration. The UI entry points are prepared, but those operations are not represented as working server functions yet. Better Messages capabilities depend on its installed edition and license.

## Build with GitHub Actions
1. Upload the contents of this folder to a GitHub repository (root should contain `settings.gradle.kts`, `build.gradle.kts`, and `app/`).
2. Ensure the default branch is `main` or `master`.
3. Open **Actions → Build TELEGRAF APK → Run workflow**, or push a commit.
4. Download artifact `telegraf-debug-apk`; it contains `app-debug.apk`.

## Build locally
Android Studio stable, Android SDK Platform 35, and JDK 17 are required. Open this folder in Android Studio and use **Build → Build APK(s)**, or run `gradle assembleDebug`.

Package: `com.woordex.telegraf`  
Minimum Android: 8.0 / API 26  
API base: `https://woordex.com/wp-json/woordex-bridge/v1`

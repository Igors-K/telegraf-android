package com.woordex.telegraf

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

private const val MESSENGER_URL = "https://woordex.com/messages/"
private const val SITE_HOST = "woordex.com"

class MainActivity : ComponentActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        CookieManager.getInstance().setAcceptCookie(true)

        setContent {
            var webView by remember { mutableStateOf<WebView?>(null) }

            BackHandler(enabled = webView?.canGoBack() == true) {
                webView?.goBack()
            }

            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        webView = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.loadsImagesAutomatically = true
                        settings.javaScriptCanOpenWindowsAutomatically = true
                        settings.setSupportMultipleWindows(false)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView,
                                request: WebResourceRequest
                            ): Boolean {
                                if (!request.isForMainFrame) return false
                                val uri = request.url
                                val host = uri.host?.lowercase() ?: return false
                                val path = uri.path.orEmpty()

                                // BuddyPress member profiles: open outside the messenger WebView.
                                if (host == SITE_HOST &&
                                    (path.startsWith("/members/") || path.startsWith("/profile/"))) {
                                    openExternal(uri)
                                    return true
                                }

                                // WordPress/SocialV login handoff: after the login POST,
                                // return to the Better Messages route and refresh it.
                                if (host == SITE_HOST && isSocialLoginPath(path)) {
                                    view.post { view.loadUrl(MESSENGER_URL) }
                                    return true
                                }

                                // Keep all other top-level navigation behavior unchanged.
                                // Embedded YouTube/player frames and media resources are not
                                // main-frame navigations and therefore remain inside the page.
                                return false
                            }
                        }

                        loadUrl(MESSENGER_URL)
                    }
                },
                update = { webView = it }
            )
        }
    }

    private fun isSocialLoginPath(path: String): Boolean {
        val p = path.lowercase()
        return p == "/login" || p == "/login/" ||
            p == "/wp-login.php" || p.startsWith("/socialv-login") ||
            p.startsWith("/signin")
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
            })
        } catch (_: Exception) {
            // If no browser can handle the profile link, leave the messenger open.
        }
    }
}

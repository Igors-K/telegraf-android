# TELEGRAF Android 0.4.0 — WOORDEX Better Messages WebView

Archive root folder intentionally named `telegraf-android`, matching the existing GitHub Actions extraction layout:
`unzip -q TELEGRAF-Android-0.4.0-GitHub.zip -d source`

Build working directory: `source/telegraf-android`.
App URL: https://woordex.com/messages/

Behavior:
- Messenger route is the app's primary page.
- Cookies, JavaScript, DOM storage and third-party cookies enabled for login/session and embeds.
- SocialV / WordPress login redirect paths return to Messenger with refresh.
- BuddyPress profiles under `/members/` or `/profile/` open in external browser.
- Non-main-frame navigation and other links are not globally blocked, preserving embed/player behavior.

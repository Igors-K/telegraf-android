package com.woordex.telegraf

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val BASE = "https://woordex.com/wp-json/woordex-bridge/v1"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("telegraf", MODE_PRIVATE)
        setContent {
            var themeChoice by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
            val dark = when (themeChoice) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            TelegrafTheme(dark) {
                TelegrafApp(
                    prefs = prefs,
                    themeChoice = themeChoice,
                    onThemeChange = {
                        themeChoice = it
                        prefs.edit().putString("theme", it).apply()
                    }
                )
            }
        }
    }
}

@Composable
private fun TelegrafTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF8AB4F8), background = Color(0xFF111318), surface = Color(0xFF1A1D24),
        onBackground = Color(0xFFE8EAF0), onSurface = Color(0xFFE8EAF0), secondary = Color(0xFF9AA8BC)
    ) else lightColorScheme(
        primary = Color(0xFF315F9E), background = Color(0xFFF5F7FA), surface = Color.White,
        onBackground = Color(0xFF18202B), onSurface = Color(0xFF18202B), secondary = Color(0xFF65758B)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

data class ChatItem(val id: String, val title: String, val preview: String, val unread: Int = 0)
data class MessageItem(val id: String, val text: String, val mine: Boolean)

@Composable
private fun TelegrafApp(prefs: android.content.SharedPreferences, themeChoice: String, onThemeChange: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(prefs.getString("token", null)) }
    var username by remember { mutableStateOf(prefs.getString("username", "") ?: "") }
    var chats by remember { mutableStateOf<List<ChatItem>>(emptyList()) }
    var selected by remember { mutableStateOf<ChatItem?>(null) }
    var messages by remember { mutableStateOf<List<MessageItem>>(emptyList()) }
    var screen by remember { mutableStateOf("home") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }

    suspend fun loadChats() {
        val t = token ?: return
        try { chats = Api.threads(t) } catch (e: Exception) { error = e.message ?: "Не удалось загрузить диалоги" }
    }
    suspend fun loadThread(chat: ChatItem) {
        val t = token ?: return
        try { messages = Api.thread(t, chat.id) } catch (e: Exception) { error = e.message ?: "Не удалось открыть диалог" }
    }

    LaunchedEffect(token) { if (token != null) loadChats() }
    LaunchedEffect(selected?.id, token) {
        val current = selected ?: return@LaunchedEffect
        while (token != null) {
            loadThread(current)
            delay(12000)
        }
    }

    if (token == null) {
        LoginScreen(busy, error, onLogin = { user, pass ->
            scope.launch {
                busy = true; error = ""
                try {
                    val result = withContext(Dispatchers.IO) { Api.login(user, pass) }
                    token = result.first
                    username = result.second
                    prefs.edit().putString("token", result.first).putString("username", result.second).apply()
                } catch (e: Exception) { error = e.message ?: "Ошибка входа" }
                busy = false
            }
        })
        return
    }

    if (showSettings) {
        SettingsScreen(themeChoice, onThemeChange, onBack = { showSettings = false }, onLogout = {
            scope.launch { try { Api.logout(token!!) } catch (_: Exception) {} }
            prefs.edit().remove("token").apply(); token = null; selected = null; showSettings = false
        })
        return
    }

    if (selected != null) {
        val chat = selected!!
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selected = null; screen = "home" }) { Icon(Icons.Default.ArrowBack, null) }
                Column(Modifier.weight(1f)) {
                    Text(chat.title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text("TELEGRAF · WOORDEX", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp)
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), reverseLayout = true, contentPadding = PaddingValues(vertical = 14.dp)) {
                items(messages.reversed()) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (msg.mine) MaterialTheme.colorScheme.primary.copy(alpha = .18f) else MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(18.dp), modifier = Modifier.padding(vertical = 4.dp).widthIn(max = 300.dp)) {
                            Text(msg.text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Сообщение…") }, maxLines = 4)
                IconButton(enabled = draft.isNotBlank(), onClick = {
                    val text = draft.trim(); draft = ""
                    scope.launch {
                        try { Api.send(token!!, chat.id, text); loadThread(chat); loadChats() }
                        catch (e: Exception) { error = e.message ?: "Не удалось отправить"; draft = text }
                    }
                }) { Icon(Icons.Default.Send, "Отправить", tint = MaterialTheme.colorScheme.primary) }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TELEGRAF", fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Messaging by WOORDEX", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Настройки") }
            }
            if (error.isNotBlank()) Text(error, Modifier.fillMaxWidth().padding(12.dp), color = MaterialTheme.colorScheme.error)
            if (chats.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Пока нет диалогов", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Text("Когда появятся сообщения, они будут здесь", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                        TextButton(onClick = { scope.launch { loadChats() } }) { Text("Обновить") }
                    }
                }
            } else LazyColumn {
                items(chats) { chat ->
                    Row(Modifier.fillMaxWidth().clickable { selected = chat; scope.launch { loadThread(chat) } }.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                            Text(chat.title.take(1).uppercase(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(chat.title, fontWeight = FontWeight.SemiBold)
                            Text(chat.preview, color = MaterialTheme.colorScheme.secondary, maxLines = 1, fontSize = 13.sp)
                        }
                        if (chat.unread > 0) Badge { Text(chat.unread.toString()) }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .35f))
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(busy: Boolean, error: String, onLogin: (String, String) -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("TELEGRAF", fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text("Messaging by WOORDEX", color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 4.dp, bottom = 34.dp))
        Text("Вход в аккаунт", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        Text("Используй тот же логин и пароль, что и на WOORDEX.", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Логин WOORDEX") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
        Button(onClick = { onLogin(user.trim(), pass) }, enabled = !busy && user.isNotBlank() && pass.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 22.dp).height(52.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("Войти")
        }
        Text("Защищённое соединение · HTTPS", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 20.dp))
    }
}

@Composable
private fun SettingsScreen(themeChoice: String, onThemeChange: (String) -> Unit, onBack: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Настройки", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Оформление", Modifier.padding(start = 18.dp, top = 24.dp, bottom = 8.dp), color = MaterialTheme.colorScheme.secondary)
        listOf("system" to "Как на телефоне", "light" to "Светлая тема", "dark" to "Тёмная тема").forEach { (value, label) ->
            Row(Modifier.fillMaxWidth().clickable { onThemeChange(value) }.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (value == "dark") Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = MaterialTheme.colorScheme.primary)
                Text(label, Modifier.weight(1f).padding(start = 14.dp))
                RadioButton(selected = themeChoice == value, onClick = { onThemeChange(value) })
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth().padding(18.dp)) { Text("Выйти из аккаунта") }
    }
}

private object Api {
    private fun request(path: String, method: String = "GET", token: String? = null, body: JSONObject? = null): JSONObject {
        val conn = (URL("$BASE$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            if (token != null) setRequestProperty("X-Woordex-Token", token)
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("raw", raw) }
            if (code !in 200..299) throw IllegalStateException(json.optString("message", "Ошибка сервера ($code)"))
            return json
        } finally { conn.disconnect() }
    }
    suspend fun login(username: String, password: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val r = request("/auth/login", "POST", body = JSONObject().put("username", username).put("password", password))
        val token = r.optString("access_token")
        if (token.isBlank()) throw IllegalStateException("Сервер не вернул токен доступа")
        val u = r.optJSONObject("user")?.optString("display_name")?.takeIf { it.isNotBlank() } ?: username
        token to u
    }
    suspend fun logout(token: String) = withContext(Dispatchers.IO) { request("/auth/logout", "POST", token, JSONObject()) }
    suspend fun threads(token: String): List<ChatItem> = withContext(Dispatchers.IO) {
        val r = request("/threads", token = token)
        val arr = findArray(r, listOf("threads", "data", "items"))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("thread_id", o.optString("id"))
                if (id.isBlank() || id == "0") continue
                val title = first(o, "title", "subject", "name").ifBlank { "Диалог $id" }
                val last = o.optJSONObject("lastMessage") ?: o.optJSONObject("last_message")
                val preview = last?.let { first(it, "message", "content", "text") } ?: first(o, "message", "last_message", "content")
                add(ChatItem(id, title, preview))
            }
        }
    }
    suspend fun thread(token: String, id: String): List<MessageItem> = withContext(Dispatchers.IO) {
        val r = request("/thread/$id", "POST", token, JSONObject())
        val arr = findArray(r, listOf("messages", "data", "items"))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val mid = o.optString("id", i.toString())
                val text = first(o, "message", "content", "text", "message_content")
                if (text.isNotBlank()) add(MessageItem(mid, text, o.optBoolean("isMine", o.optBoolean("is_mine", false))))
            }
        }
    }
    suspend fun send(token: String, id: String, content: String) = withContext(Dispatchers.IO) {
        request("/thread/$id/send", "POST", token, JSONObject().put("content", content))
    }
    private fun first(o: JSONObject, vararg keys: String): String = keys.firstNotNullOfOrNull { k -> o.optString(k).takeIf { it.isNotBlank() && it != "null" } } ?: ""
    private fun findArray(o: JSONObject, keys: List<String>): JSONArray {
        keys.forEach { key -> o.optJSONArray(key)?.let { return it } }
        keys.forEach { key -> o.optJSONObject(key)?.let { nested ->
            listOf("threads", "messages", "items", "data").forEach { n -> nested.optJSONArray(n)?.let { return it } }
        } }
        return JSONArray()
    }
}

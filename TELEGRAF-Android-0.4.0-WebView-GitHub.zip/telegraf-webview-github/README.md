# TELEGRAF Android 0.4.0 — WebView shell for WOORDEX Better Messages

This version wraps the existing Better Messages page:
`https://woordex.com/messages/`

## Behavior
- Messenger remains the in-app home screen.
- WordPress cookies and web storage are enabled for persistent login.
- SocialV/WordPress login handoff paths are intercepted and return to `/messages/` with a page reload.
- BuddyPress profile paths (`/members/...` and `/profile/...`) open in the Android browser.
- Only main-frame profile/login navigation is intercepted. Embedded frames, YouTube embeds, media resources, and other page behavior are left to the website/WebView.
- Android back navigates WebView history when available.

## GitHub Actions build
Upload the contents of this folder to the repository root (not the ZIP itself). GitHub Actions builds a debug APK on push or via Actions → Build TELEGRAF APK → Run workflow. Download `telegraf-debug-apk`.

## Build
Android SDK 35 and JDK 17; Gradle 8.9+ compatible with Android Gradle Plugin 8.7.3.
